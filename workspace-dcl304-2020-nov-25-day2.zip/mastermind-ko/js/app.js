let gameViewModel = new GameViewModel();
window.onload = () => {
    ko.applyBindings(gameViewModel);
}
